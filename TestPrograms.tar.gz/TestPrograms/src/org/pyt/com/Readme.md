Question - 1 MovieTitle.java

Question - 2 MaxDiff.java

Question - 3 BalancedStrings.java 
