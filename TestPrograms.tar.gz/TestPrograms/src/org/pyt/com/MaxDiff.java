package org.pyt.com;


import java.util.Scanner;

public class MaxDiff {
	
	
	public static void differnceArray() {
		
		  Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter number of elements");

	        int n = scanner.nextInt();
	        int arr[] = new int[n];

	        System.out.println("Enter elements");

	        for(int i = 0;i < n;i++){
	            arr[i] = scanner.nextInt();
	        }

	        Integer maxDiff = arr[1] - arr[0];
	        
	        for(int oar = 0;  oar < arr.length; oar++ ) {
	        	Integer outerArrayValues = arr[oar];
	        	
	        	for(int iar = oar + 1 ; iar < arr.length; iar ++) {
	        		
	        		Integer innerArrayValues = arr[iar];
	        		
	        		if((innerArrayValues -  outerArrayValues) > maxDiff) {
	        			maxDiff =  innerArrayValues - outerArrayValues;
	        			
	        		}	        		
	        	}	        	
	        }
	        
	        System.out.println(maxDiff);		
		
	}
	
	

	public static void main(String[] args) {
		differnceArray();
	}

}
