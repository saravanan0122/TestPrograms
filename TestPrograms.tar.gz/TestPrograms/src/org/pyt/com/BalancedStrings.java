package org.pyt.com;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.*;



public class BalancedStrings {
	
	
	public static void StringRegex( ) {
		
		try {
			BufferedReader	br = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println(" Enter a String: ");
			
			String inputString = br.readLine();
			
		/*	String pattern1 = "(([bd]*[ac]){2})*[bd]*";  // summed number of a and c is even
			String pattern2 = "(([ac]*[bd]){2})*[ac]*"; // summed number of b and d is even
		*/	
			
			String regexPattern = "(?=^(([ac]*[bd]){2})*[ac]*$)(([bd]*[ac]){2})*[bd]*";
			
			 Pattern p = Pattern.compile(regexPattern);
		     Matcher m = p.matcher(inputString);
		     
		     System.out.println(m.matches());
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String[] args) {
		
		StringRegex();		

	}

}
